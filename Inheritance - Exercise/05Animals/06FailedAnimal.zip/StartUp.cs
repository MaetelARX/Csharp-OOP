﻿using System.Text;

namespace Animals
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            StringBuilder sb = new StringBuilder();
            string animal = Console.ReadLine();
            while (animal != "Beast!")
            {
                try
                {
                    string[] input = Console.ReadLine().Split().ToArray();
                    string name = input[0];
                    uint age = uint.Parse(input[1]);
                    string gender = input[2];

                    if (animal == "Dog")
                    {
                        Dog dog = new Dog(name, age, gender);
                        sb.AppendLine($"Dog\n{dog.ToString()}");
                    }
                    else if (animal == "Cat")
                    {
                        Cat cat = new Cat(name, age, gender);
                        sb.AppendLine($"Cat\n{cat.ToString()}");
                    }
                    else if (animal == "Frog")
                    {
                        Frog frog = new Frog(name, age, gender);
                        sb.AppendLine($"Frog\n{frog.ToString()}");
                    }
                    else if (animal == "Kitten")
                    {
                        Kitten kittens = new Kitten(name, age, gender);
                        sb.AppendLine($"Kitten\n{kittens.ToString()}");
                    }
                    else if (animal == "Tomcat")
                    {
                        Tomcat tomCat = new Tomcat(name, age, gender);
                        sb.AppendLine($"Tomcat\n{tomCat.ToString()}");
                    }
                    animal = Console.ReadLine();
                }
                catch (Exception)
                {
                    sb.AppendLine("Invalid input!");
                    animal = Console.ReadLine();
                }
            }
            Console.WriteLine(sb.ToString());
        }
    }
}

