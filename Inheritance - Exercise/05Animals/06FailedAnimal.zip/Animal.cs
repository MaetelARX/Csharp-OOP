﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animals
{
    public class Animal
    {
        public string Name { get; set; }
        public uint Age { get; set; }
        public string Gender { get; set; }

        public Animal(string name, uint age, string gender)
        {
            Name = name;
            Age = age;
            Gender = gender;
        }
        public virtual string ProduceSound()
        {
            return default;
        }
        public override string ToString()
        {
            return $"{Name} {Age} {Gender}\n{ProduceSound()}";
        }
    }
}
