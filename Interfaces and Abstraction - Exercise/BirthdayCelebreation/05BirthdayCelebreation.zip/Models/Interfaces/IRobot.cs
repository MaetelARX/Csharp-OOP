﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BirthdayCelebreation.Models.Interfaces
{
    public interface IRobot
    {
        public string RobotPrint(string input, string test);
    }
}
