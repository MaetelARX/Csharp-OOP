﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BirthdayCelebreation.Models.Interfaces
{
    public interface ICitizen
    {
        public string CitizenPrint(string input, string test);
    }
}
