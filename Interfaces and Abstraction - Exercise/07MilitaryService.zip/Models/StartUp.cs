﻿using MilitaryElite.Core;
using MilitaryService.Core.Interfaces;

namespace MilitaryService
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            IEngine engine = new Engine();
            engine.Run();
        }
    }
}