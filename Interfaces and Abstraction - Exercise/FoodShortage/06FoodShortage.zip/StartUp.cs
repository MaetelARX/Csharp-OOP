﻿using FoodShortage.Models;
using FoodShortage.Models.Interfaces;

namespace FoodShortage
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            List<string> Citizen = new List<string>();
            List<string> Rebel = new List<string>();

            for (int i = 0; i < n; i+=2)
            {
                string citizen = Console.ReadLine();
                string rebel = Console.ReadLine();

                Citizen.Add(citizen);
                Rebel.Add(rebel);
            }
            int sum = 0;
            IBuyer buyer = new Rebel();
            while (true)
            {
                string name = Console.ReadLine();
                if(name == "End")
                {
                    break;
                }
                foreach(var item in Citizen)
                {
                    if (item.Contains(name))
                    {
                        sum += 10;
                    }
                }
                foreach(var item in Rebel)
                {
                    if (item.Contains(name))
                    {
                        sum += 5;
                    }
                }
            }
            Console.WriteLine(buyer.BuyFood(sum));
        }
    }
}