﻿using FoodShortage.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodShortage.Models
{
    public class Person : IPerson
    {
        public string Name { get; }

        public int Age { get; }

        public Person(string name, int age) 
        {
            Name = name;
            Age = age;
            Food = 0;
        }

        public void BuyFood()
        {
            
        }

        public int Food { get; protected set; }
    }
}
