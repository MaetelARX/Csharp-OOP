﻿namespace PersonsInfo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            int lines = int.Parse(Console.ReadLine());
            List<Person> list = new List<Person>();
            
            for(int i = 0; i < lines; i++)
            {
                string[] input = Console.ReadLine().Split().ToArray();
                Person person = new Person(input[0], input[1], int.Parse(input[2]));
                list.Add(person);
            }
            list.OrderBy(p => p.FirstName)
                .ThenBy(p => p.Age)
                .ToList()
                .ForEach(p => Console.WriteLine(p.ToString()));
        }
    }
}