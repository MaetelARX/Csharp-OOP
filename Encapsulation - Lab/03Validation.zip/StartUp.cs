﻿namespace PersonsInfo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            int lines = int.Parse(Console.ReadLine());
            List<Person> list = new List<Person>();
            
            for(int i = 0; i < lines; i++)
            {
                try
                {
                    string[] input = Console.ReadLine().Split().ToArray();
                    Person person = new Person(input[0], input[1], int.Parse(input[2]), decimal.Parse(input[3]));
                    list.Add(person);
                }
                catch(Exception ex) 
                {
                    Console.WriteLine(ex.Message);
                }
            }
            decimal percentage = decimal.Parse(Console.ReadLine());
            list.ForEach(p => p.IncreaseSalary(percentage));
            list.ForEach(p => Console.WriteLine(p.ToString()));
        }
    }
}