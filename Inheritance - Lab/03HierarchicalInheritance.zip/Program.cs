﻿namespace Farm
{
    public class StartUp
    {
        public static void Main()
        {
            Cat cat = new Cat();
            cat.Eat();
            cat.Meow();

            Dog dog = new Dog();
            dog.Eat();
            dog.Bark();
        }
    }
}
