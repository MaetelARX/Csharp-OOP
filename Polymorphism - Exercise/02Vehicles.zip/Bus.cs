﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    public class Bus : Vehicle
    {
        public Bus(double fuelquantity, double fuelconsumptioninliterperkm, double tankcapacity) : base(fuelquantity, fuelconsumptioninliterperkm, tankcapacity)
        {
        }
        public void Empty(string input)
        {
            if (input == "Drive")
            {
                FuelConsumptionInLitersPerKm = base.FuelConsumptionInLitersPerKm;
                base.FuelConsumptionInLitersPerKm += 1.4;
            }
            else if (input == "DriveEmpty")
            {
                FuelConsumptionInLitersPerKm = base.FuelConsumptionInLitersPerKm;
            }
        }
    }
}
