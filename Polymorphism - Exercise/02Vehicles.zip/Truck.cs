﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    public class Truck : Vehicle
    {
        public Truck(double fuelquantity, double fuelconsumption, double tankcapacity) : base(fuelquantity, fuelconsumption, tankcapacity)
        {
        }
        public override double FuelConsumptionInLitersPerKm
            => base.FuelConsumptionInLitersPerKm + 1.6;
        public override void Refuel(double amount)
        {
            base.Refuel(amount);
        }
    }
}
