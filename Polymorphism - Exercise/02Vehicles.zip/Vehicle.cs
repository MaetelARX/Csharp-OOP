﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    public abstract class Vehicle
    {
		private double fuelquantity;
		private double fuelconsumption;
		private double tankcapacity;

		public Vehicle(double fuelquantity, double fuelconsumptioninliterperkm, double tankcapacity)
		{
			FuelQuantity = fuelquantity;
			FuelConsumptionInLitersPerKm = fuelconsumptioninliterperkm;
            TankCapacity = tankcapacity;
		}

        protected Vehicle(double fuelquantity, double fuelconsumption)
        {
            this.fuelquantity = fuelquantity;
            this.fuelconsumption = fuelconsumption;
        }

        public double TankCapacity
        {
            get { return tankcapacity; }
            set { tankcapacity = value; }
        }
        public virtual double FuelConsumptionInLitersPerKm
		{
			get { return fuelconsumption; }
			set { fuelconsumption = value; }
		}


		public double FuelQuantity
		{
			get { return fuelquantity; }
			set { fuelquantity = value; }
		}
        public bool CanDrive(double km) => FuelQuantity - km * FuelConsumptionInLitersPerKm >= 0;
        public bool OverTankCapacity(double km) => FuelQuantity + km * FuelConsumptionInLitersPerKm > TankCapacity;

        public virtual void Drive(double km)
        {
            if (CanDrive(km))
            {
                FuelQuantity -= km * FuelConsumptionInLitersPerKm;
                Console.WriteLine($"{GetType().Name} travelled {km} km");
            }
			else
			{
                throw new ArgumentException($"{GetType().Name} needs refueling");
            }
        }

		public virtual void Refuel(double amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Fuel must be a positive number");
            }
            else if (!OverTankCapacity(amount))
            {
                FuelQuantity += amount;
            }
            else
            {
                throw new ArgumentException($"Cannot fit {amount} fuel in the tank");
            }
        }
    }
}
