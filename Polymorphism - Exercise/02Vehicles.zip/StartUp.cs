﻿namespace Vehicles
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string[] cars = Console.ReadLine().Split();
            string[] trucks = Console.ReadLine().Split();
            string[] buses = Console.ReadLine().Split();

            double carFuel = double.Parse(cars[1]);
            double carQuantity = double.Parse(cars[2]);
            double carTankCapacity = double.Parse(cars[3]);

            double truckFuel = double.Parse(trucks[1]);
            double truckQuantity = double.Parse(trucks[2]);
            double truckTankCapacity = double.Parse(trucks[3]);

            double busFuel = double.Parse(buses[1]);
            double busQuantity = double.Parse(buses[2]);
            double busTankCapacity = double.Parse(buses[3]);

            Car car = new(carFuel, carQuantity,carTankCapacity);
            Truck truck = new(truckFuel, truckQuantity, truckTankCapacity);
            Bus bus = new(busFuel, busQuantity, busTankCapacity);

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] command = Console.ReadLine().Split();
                string action = command[0];
                string type = command[1];
                double fuel = double.Parse(command[2]);

                if (action == "Drive" || action == "DriveEmpty")
                {
                    if (type == "Car")
                    {
                        if (car.CanDrive(fuel))
                        {
                            car.Drive(fuel);
                        }
                        else
                        {
                            Console.WriteLine("Car needs refueling");
                        }
                    }
                    else if (type == "Truck")
                    {
                        if (truck.CanDrive(fuel))
                        {
                            truck.Drive(fuel);
                        }
                        else
                        {
                            Console.WriteLine("Truck needs refueling");
                        }
                    }
                    else if (type == "Bus")
                    {
                        bus.Empty(action);

                        if (bus.CanDrive(fuel))
                        {
                            bus.Drive(fuel);
                        }
                        else
                        {
                            Console.WriteLine("Bus needs refueling");
                        }
                    }
                }
                else
                {
                    if (type == "Car")
                    {
                        if (!car.OverTankCapacity(fuel))
                        {
                            car.Refuel(fuel);
                        }
                        else
                        {
                            car.Refuel(fuel);
                        }
                    }
                    else if (type == "Truck")
                    {
                        if (!truck.OverTankCapacity(fuel))
                        {
                            truck.Refuel(fuel);
                        }
                        else
                        {
                            truck.Refuel(fuel);
                        }
                    }
                    else
                    {
                        if (!bus.OverTankCapacity(fuel))
                        {
                            bus.Refuel(fuel);
                        }
                        else
                        {
                            bus.Refuel(fuel);
                        }
                    }
                }
            }
            Console.WriteLine($"Car: {car.FuelQuantity:f2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:f2}");
            Console.WriteLine($"Bus: {bus.FuelQuantity:f2}");
        }
    }
}