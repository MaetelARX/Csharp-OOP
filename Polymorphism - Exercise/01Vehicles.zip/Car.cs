﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    public class Car : Vehicle
    {
        public Car(double fuelquantity, double fuelconsumption) : base(fuelquantity, fuelconsumption)
        {
        }

        public override double FuelConsumptionInLitersPerKm => base.FuelConsumptionInLitersPerKm + 0.9;
        public override void Drive(double km)
        {
            base.Drive(km);
        }
    }
}
