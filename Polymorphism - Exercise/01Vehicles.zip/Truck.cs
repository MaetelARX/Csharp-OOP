﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    public class Truck : Vehicle
    {
        public Truck(double fuelquantity, double fuelconsumption) : base(fuelquantity, fuelconsumption)
        {
        }
        public override double FuelConsumptionInLitersPerKm
            => base.FuelConsumptionInLitersPerKm + 1.6;
        public override void Refuel(double amount)
        {
            amount *= 0.95;
            base.Refuel(amount);
        }
    }
}
