﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicles
{
    public abstract class Vehicle
    {
		private double fuelquantity;
		private double fuelconsumption;

		public Vehicle(double fuelquantity, double fuelconsumptioninliterperkm)
		{
			FuelQuantity = fuelquantity;
			FuelConsumptionInLitersPerKm = fuelconsumptioninliterperkm;
		}

		public virtual double FuelConsumptionInLitersPerKm
		{
			get { return fuelconsumption; }
			set { fuelconsumption = value; }
		}


		public double FuelQuantity
		{
			get { return fuelquantity; }
			set { fuelquantity = value; }
		}
        public bool CanDrive(double km) => FuelQuantity - km * FuelConsumptionInLitersPerKm >= 0;

        public virtual void Drive(double km)
        {
            if (CanDrive(km))
            {
                FuelQuantity -= km * FuelConsumptionInLitersPerKm;
                Console.WriteLine($"{GetType().Name} travelled {km} km");
            }
			else
			{
                Console.WriteLine($"{GetType().Name} needs refueling");
            }
        }

		public virtual void Refuel(double amount) => FuelQuantity += amount;
    }
}
