﻿namespace Vehicles
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string[] cars = Console.ReadLine().Split();
            string[] trucks = Console.ReadLine().Split();

            double carFuel = double.Parse(cars[1]);
            double carQuantity = double.Parse(cars[2]);

            double truckFuel = double.Parse(trucks[1]);
            double truckQuantity = double.Parse(trucks[2]);

            Car car = new(carFuel, carQuantity);
            Truck truck = new(truckFuel, truckQuantity);

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] command = Console.ReadLine().Split();
                string action = command[0];
                string type = command[1];
                double fuel = double.Parse(command[2]);

                if (action == "Drive")
                {
                    if (type == "Car")
                    {
                        if (car.CanDrive(fuel))
                        {
                            car.Drive(fuel);
                        }
                        else
                        {
                            Console.WriteLine("Car needs refueling");
                        }
                    }
                    else
                    {
                        if (truck.CanDrive(fuel))
                        {
                            truck.Drive(fuel);
                        }
                        else
                        {
                            Console.WriteLine("Truck needs refueling");
                        }
                    }
                }
                else
                {
                    if (type == "Car")
                    {
                        car.Refuel(fuel);
                    }
                    else
                    {
                        truck.Refuel(fuel);
                    }
                }
            }
            Console.WriteLine($"Car: {car.FuelQuantity:f2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:f2}");
        }
    }
}