﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WildFarm.FoodModels
{
    public class Vegetable : Food
    {
        public Vegetable(int qunatity) : base(qunatity)
        {
        }
    }
}
